function alterarTitulo() {
    document.querySelector("h1").textContent = "Mochila";} //primeira//
    
    function alterarImagem() {
        document.getElementById("minhaImagem").src = "https://wallpapers.com/images/hd/4k-universe-blue-galaxy-mmrwwhw8cy5lzxty.jpg";
    } //segunda//

    function toggleTabela() {
        const tabela = document.getElementById("minhaTabela");
        const botao = document.querySelector("button");

        if (tabela.style.display === "none") {
            tabela.style.display = "table";
            botao.textContent = "Ocultar Tabela";
        } else {
            tabela.style.display = "none"; botao.textContent = "Mostrar Tabela";
        } //terceira//
    }
    function mostrarNome() {
        alert("Igor"); 
    } //quita//

    document.getElementById('alterarLinkButton').addEventListener('click', function() {
        const novoLink = 'https://vasco.com.br/futebol-elenco-profissional/';
        const linkElement = document.getElementById('meuLink');
        linkElement.href = novoLink;
        linkElement.textContent = novoLink;
    }); //quarta//